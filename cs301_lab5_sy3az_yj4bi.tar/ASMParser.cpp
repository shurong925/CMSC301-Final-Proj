#include "ASMParser.h"
#include <iostream>
#include <queue>

ASMParser::ASMParser(string filename)
  // Specify a text file containing MIPS assembly instructions. Function
  // checks syntactic correctness of file and creates a list of Instructions.
{
  Instruction i;
  myFormatCorrect = true;

  myLabelAddress = 0x400000;

  ifstream in;
  in.open(filename.c_str());
  if(in.bad()){
    myFormatCorrect = false;
  }
  else
  {
    string line;
    while(getline(in, line))
    {
      string opcode("");
      string operand[80];
      int operand_count = 0;
        
      inputValues.push_back(line);
        
      getTokens(line, opcode, operand, operand_count);

      if(opcode.length() == 0 && operand_count != 0)
      {
        // No opcode but operands
        myFormatCorrect = false;
        break;
      }

      Opcode o = opcodes.getOpcode(opcode);
      if(o == UNDEFINED)
      {
        // invalid opcode specified
        myFormatCorrect = false;
        break;
      }

      bool success = getOperands(i, o, operand, operand_count);
      if(!success)
      {
        myFormatCorrect = false;
        break;
      }
        
      string encoding = encode(i);
      i.setEncoding(encoding);

      myInstructions.push_back(i);

    }
  }
    // This loop iterates the list of inputValues and finds the labels.
    // Then, it pushes the stripped string of instruction into the list of strippedInstructions
    // and the 26-bit(already taken out PC+4) binary string of the address of the label
    for(int i = 0; i < inputValues.size(); i++)
     {
         //label: addi $t0, $t0, 1
         if(inputValues.at(i).substr(0,5) == "label")
        {
            strippedInstructions.push_back(inputValues.at(i).substr(7));
            symbolTable.push(binaryConverter(getAddress(i),32).substr(4,26));
        }
     }
  myIndex = 0;
}


Instruction ASMParser::getNextInstruction()
  // Iterator that returns the next Instruction in the list of Instructions.
{
  if(myIndex < (int)(myInstructions.size())){
    myIndex++;
    return myInstructions[myIndex-1];
  }

  Instruction i;
  return i;
    
}

void ASMParser::getTokens(string line,
			       string &opcode,
			       string *operand,
			       int &numOperands)
  // Decomposes a line of assembly code into strings for the opcode field and operands,
  // checking for syntax errors and counting the number of operands.
{
    // locate the start of a comment
    string::size_type idx = line.find('#');
    if (idx != string::npos) // found a ';'
	line = line.substr(0,idx);
    int len = line.length();
    opcode = "";
    numOperands = 0;

    if (len == 0) return;
    int p = 0; // position in line

    // line.at(p) is whitespace or p >= len
    while (p < len && isWhitespace(line.at(p)))
	p++;
    // opcode starts
    while (p < len && !isWhitespace(line.at(p)))
    {
	opcode = opcode + line.at(p);
	p++;
    }
    //    for(int i = 0; i < 3; i++){
    int i = 0;
    while(p < len){
      while ( p < len && isWhitespace(line.at(p)))
	p++;

      // operand may start
      bool flag = false;
      while (p < len && !isWhitespace(line.at(p)))
	{
	  if(line.at(p) != ','){
	    operand[i] = operand[i] + line.at(p);
	    flag = true;
	    p++;
	  }
	  else{
	    p++;
	    break;
	  }
	}
      if(flag == true){
	numOperands++;
      }
      i++;
    }


    idx = operand[numOperands-1].find('(');
    string::size_type idx2 = operand[numOperands-1].find(')');

    if (idx == string::npos || idx2 == string::npos ||
	((idx2 - idx) < 2 )){ // no () found
    }
    else{ // split string
      string offset = operand[numOperands-1].substr(0,idx);
      string regStr = operand[numOperands-1].substr(idx+1, idx2-idx-1);

      operand[numOperands-1] = offset;
      operand[numOperands] = regStr;
      numOperands++;
    }



    // ignore anything after the whitespace after the operand
    // We could do a further look and generate an error message
    // but we'll save that for later.
    return;
}

bool ASMParser::isNumberString(string s)
  // Returns true if s represents a valid decimal integer
{
    int len = s.length();
    if (len == 0) return false;
    if ((isSign(s.at(0)) && len > 1) || isDigit(s.at(0)))
    {
	// check remaining characters
	for (int i=1; i < len; i++)
	{
	    if (!isdigit(s.at(i))) return false;
	}
	return true;
    }
    return false;
}


int ASMParser::cvtNumString2Number(string s)
  // Converts a string to an integer.  Assumes s is something like "-231" and produces -231
{
    if (!isNumberString(s))
    {
	std::cerr << "Non-numberic string passed to cvtNumString2Number"
		  << std::endl;
	return 0;
    }
    int k = 1;
    int val = 0;
    for (int i = s.length()-1; i>0; i--)
    {
	char c = s.at(i);
	val = val + k*((int)(c - '0'));
	k = k*10;
    }
    if (isSign(s.at(0)))
    {
	if (s.at(0) == '-') val = -1*val;
    }
    else
    {
	val = val + k*((int)(s.at(0) - '0'));
    }
    return val;
}


bool ASMParser::getOperands(Instruction &i, Opcode o,
			    string *operand, int operand_count)
  // Given an Opcode, a string representing the operands, and the number of operands,
  // breaks operands apart and stores fields into Instruction.
{

  if(operand_count != opcodes.numOperands(o))
    return false;

  int rs, rt, rd, imm;
  imm = 0;
  rs = rt = rd = NumRegisters;

  int rs_p = opcodes.RSposition(o);
  int rt_p = opcodes.RTposition(o);
  int rd_p = opcodes.RDposition(o);
  int imm_p = opcodes.IMMposition(o);

  if(rs_p != -1){
    rs = registers.getNum(operand[rs_p]);
    if(rs == NumRegisters)
      return false;
  }

  if(rt_p != -1){
    rt = registers.getNum(operand[rt_p]);
    if(rt == NumRegisters)
      return false;

  }

  if(rd_p != -1){
    rd = registers.getNum(operand[rd_p]);
    if(rd == NumRegisters)
      return false;

  }

  if(imm_p != -1){
    if(isNumberString(operand[imm_p])){  // does it have a numeric immediate field?
      imm = cvtNumString2Number(operand[imm_p]);
      if(((abs(imm) & 0xFFFF0000)<<1))  // too big a number to fit
	return false;
    }
    else{
      if(opcodes.isIMMLabel(o)){  // Can the operand be a label?
	// Assign the immediate field an address
	imm = myLabelAddress;
	myLabelAddress += 4;  // increment the label generator
      }
      else  // There is an error
	return false;
    }

  }

  i.setValues(o, rs, rt, rd, imm);

  return true;
}

// Helper function for converting an integer(register) to binary string
string ASMParser::binaryConverter(int n, int digit)
{
    bitset<32> b (n); //b is initialized with bits of 32 representing n
    return b.to_string().substr(32-digit, digit); //get the number of digits wanted
}

// Helper function for getting the address of label
int ASMParser::getAddress(int num)
{
    return stoi("0x400000", 0, 16)+ num*4;
}


string ASMParser::encode(Instruction i)
  // Given a valid instruction, returns a string representing the 32 bit MIPS binary encoding
  // of that instruction.
{
  // Your code here
  string output = "";

  // append opcode to output
  output = output + opcodes.getOpcodeField(i.getOpcode());

  if (opcodes.getInstType(i.getOpcode()) == RTYPE)
  {
    output = output + binaryConverter(i.getRS(), 5) + binaryConverter(i.getRT(), 5) + binaryConverter(i.getRD(), 5) + binaryConverter(i.getImmediate(), 5) + opcodes.getFunctField(i.getOpcode());
  }

  if (opcodes.getInstType(i.getOpcode()) == ITYPE)
  {
    output = output + binaryConverter(i.getRS(), 5) + binaryConverter(i.getRT(), 5) + binaryConverter(i.getImmediate(), 16);
  }

  if (opcodes.getInstType(i.getOpcode()) == JTYPE)
  {
//      if(opcodes.isIMMLabel(i.getOpcode()) == true)
//      {
//          output = output + symbolTable.front();
//      }
//      else
          output = output + binaryConverter(i.getImmediate(), 32).substr(4,26);
      
  }

  return output;
}
